README

This game can be run on one computer for sampling purposes.
Simply run server first, and set the local port to 4444 or any open ports on your network.
Run the mahjong.jar to access the game. 
A simple server browser should be displayed. 
The host ip should be the external ip of the host if playing over the internet or the local ip if playing on LAN. 
REQUIRES FOUR INSTANCES CONNECTED TO THE SERVER TO START THE GAME.